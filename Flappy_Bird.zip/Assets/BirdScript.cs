using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BirdScript : MonoBehaviour
{
        public Rigidbody2D myRigidbody2D;
        public int jumpStrength;
        public float beforeJumpHeight;
        public GameObject WingLeftUp;
        public GameObject WingRightUp;
        public GameObject WingLeftDown;
        public GameObject WingRightDown;
        public LogicScript logic;
        public bool birdIsAlive = true;




    // Start is called before the first frame update
    void Start()
    {
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<LogicScript>();
        WingLeftUp = transform.Find("BirdWingLeftUp").gameObject;
        WingRightUp = transform.Find("BirdWingRightUp").gameObject;
        WingLeftDown = transform.Find("BirdWingLeftDown").gameObject;
        WingRightDown = transform.Find("BirdWingRightDown").gameObject;
        gameObject.name = "Lajos";
       
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space) && birdIsAlive)
        {
            WingLeftUp.SetActive(true);
            WingRightUp.SetActive(true);
            WingLeftDown.SetActive(false);
            WingRightDown.SetActive(false);
            myRigidbody2D.velocity = Vector2.up * jumpStrength;
            beforeJumpHeight = gameObject.transform.position.y;
        }

        if (gameObject.transform.position.y < beforeJumpHeight+1)
        {
            WingLeftUp.SetActive(false);
            WingRightUp.SetActive(false);
            WingLeftDown.SetActive(true);
            WingRightDown.SetActive(true);
        }
        else
        {
            WingLeftUp.SetActive(true);
            WingRightUp.SetActive(true);
            WingLeftDown.SetActive(false);
            WingRightDown.SetActive(false);
        }
        

    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        logic.gameOver();
        birdIsAlive = false;
    }
}
