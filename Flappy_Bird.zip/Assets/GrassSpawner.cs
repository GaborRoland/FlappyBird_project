using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrassSpawner : MonoBehaviour
{
    public GameObject Grass;
    public int GrassSpawnRate;
    private float timer = 0;

    // Start is called before the first frame update
    void Start()
    {
        SpawnGrass();
    }

    // Update is called once per frame
    void Update()
    {
        if (timer < GrassSpawnRate)
        {
            timer += Time.deltaTime;
        }
        else
        {
            SpawnGrass();
            timer = 0;
        }

    }
    void SpawnGrass()
    {

        Instantiate(Grass, new Vector3(transform.position.x, transform.position.y, 0), transform.rotation);
    }
}
