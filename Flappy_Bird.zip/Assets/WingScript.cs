using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WingScript : MonoBehaviour
{
    BirdScript asd = new BirdScript();
    
    public int idozito;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        idozito++;
        if (idozito > 50)
        {
            
        }
    }
}
